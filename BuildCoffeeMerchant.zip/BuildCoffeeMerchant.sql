-- CoffeeMerchant database developed and written by Amy Phillips
-- Originally Written: September 2005| Updated: April 2017
---------------------------------------------------------------
-- Replace <data_path> with the full path to this file 
-- Ensure it ends with a backslash. 
-- E.g., C:\MyDatabases\ See line 17
---------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE name = N'CoffeeMerchant')
	CREATE DATABASE CoffeeMerchant
GO
USE CoffeeMerchant
--
-- Alter the path so the script can find the CSV files
--
DECLARE
	@data_path nvarchar(256);
SELECT @data_path = 'C:\Users\amyphill\Data\Course Work\INFO 3240 - EIM\DB Builds\Coffee Merchant\';
--
-- =======================================
-- Delete existing tables
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'OrderLine'
       )
	DROP TABLE OrderLine;
--
-- Table Order
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'Order'
       )
	DROP TABLE [Order];
--
-- Table Consumer
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'Consumer'
       )
	DROP TABLE Consumer;
--
-- Table Inventory
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'Inventory'
       )
	DROP TABLE Inventory;
--
-- Table Employee
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'Employee'
       )
	DROP TABLE Employee;
--
-- Table State
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'State'
       )
	DROP TABLE State;
--
-- Table Country
--
IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'Country'
       )
	DROP TABLE Country;
--
-- Create tables
--
-- Table 1 Country
--
CREATE TABLE Country
	(CountryID  INT CONSTRAINT pk_country PRIMARY KEY,
	CountryName NVARCHAR(40) NOT NULL
	);
--
-- Table 2 State
--
CREATE TABLE State
	(StateID   NVARCHAR(2) CONSTRAINT pk_State PRIMARY KEY,
	StateName  NVARCHAR(25) NOT NULL,
	TaxRate    NUMERIC(7,4),
	Population INT,
	LandArea   INT,
	WebURL     NVARCHAR(50)
	);
--
-- Table 3 Employee
--
CREATE TABLE Employee
	(EmployeeID    INT CONSTRAINT pk_employee PRIMARY KEY,
	FirstName      NVARCHAR(30) NOT NULL,
	LastName       NVARCHAR(30) NOT NULL,
	WorkPhone      NVARCHAR(20),
	CommissionRate NUMERIC(4,4),
	HireDate       DATETIME,
	BirthDate      DATETIME,
	Gender         NVARCHAR(1),
	);
--
-- Table 4 Inventory
--
CREATE TABLE Inventory
	(InventoryID	INT CONSTRAINT pk_inventory PRIMARY KEY,
	Name		NVARCHAR(40) NOT NULL,
	Price		NUMERIC(6,2) NOT NULL,
	OnHand		INT,
	Description	NVARCHAR(500) NOT NULL,
	ItemType	NVARCHAR(5),
	CountryID	INT CONSTRAINT fk_inventory_country FOREIGN KEY REFERENCES Country (CountryID)
	);
--
-- Table 5 Consumer
--
CREATE TABLE Consumer
	(ConsumerID INT CONSTRAINT pk_consumer PRIMARY KEY,
	FirstName   NVARCHAR(30) NOT NULL,
	LastName    NVARCHAR(30) NOT NULL,
	Street      NVARCHAR(50) NOT NULL,
	City        NVARCHAR(50) NOT NULL,
	State       NVARCHAR(2) CONSTRAINT fk_consumer_state FOREIGN KEY REFERENCES State (StateID),
	Zipcode     NVARCHAR(11) NOT NULL,
	Phone       NVARCHAR(20),
	Fax         NVARCHAR(20),
	CreditLimit INT
	);
--
-- Table 6 Order
--
CREATE TABLE [Order]
	(OrderID   INT IDENTITY (214010, 1) CONSTRAINT pk_order PRIMARY KEY,
	OrderDate  DATETIME NOT NULL,
	ShipDate   DATETIME,
	CustomerPO NVARCHAR(15),
	ConsumerID INT CONSTRAINT fk_order_consumer FOREIGN KEY REFERENCES Consumer (ConsumerID),
	EmployeeID INT CONSTRAINT fk_order_employee FOREIGN KEY REFERENCES Employee (EmployeeID)
	);
--
-- Table 7 OrderLine
--
CREATE TABLE OrderLine
	(OrderID    INT NOT NULL,
	LineItem    INT NOT NULL,
	InventoryID INT NOT NULL,
	Quantity    INT NOT NULL,
	Price       NUMERIC(6,2),
	Discount    NUMERIC(4,4),
	CONSTRAINT pk_orderline PRIMARY KEY (OrderID, LineItem),
	CONSTRAINT fk_orderline_order FOREIGN KEY (OrderID) REFERENCES [Order] (OrderID),
	CONSTRAINT fk_orderline_inventory FOREIGN KEY (InventoryID) REFERENCES Inventory (InventoryID)
       );
--
-- Load table data
--
-- Table 1 Country
--
EXECUTE (N'BULK INSERT Country FROM ''' + @data_path + N'Countries.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- Table 2 State
--
EXECUTE (N'BULK INSERT State FROM ''' + @data_path + N'States.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- Table 3 Employee
--
EXECUTE (N'BULK INSERT Employee FROM ''' + @data_path + N'Employees.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- Table 4 Inventory
--
EXECUTE (N'BULK INSERT Inventory FROM ''' + @data_path + N'Inventory.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= ''\t'',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- Table 5 Consumer
--
EXECUTE (N'BULK INSERT Consumer FROM ''' + @data_path + N'Consumers.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
-- Table 6 Order
--
EXECUTE (N'BULK INSERT [Order] FROM ''' + @data_path + N'Orders.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	TABLOCK
	);
');
--
-- Table 7 OrderLine
--
EXECUTE (N'BULK INSERT OrderLine FROM ''' + @data_path + N'OrderLines.csv''
WITH (
	CHECK_CONSTRAINTS,
	CODEPAGE=''ACP'',
	DATAFILETYPE = ''char'',
	FIELDTERMINATOR= '','',
	ROWTERMINATOR = ''\n'',
	KEEPIDENTITY,
	TABLOCK
	);
');
--
SET NOCOUNT ON
SELECT 'Consumer' "Table",	COUNT(*) "Rows"	FROM Consumer		UNION
SELECT 'Country',		COUNT(*)		FROM Country		UNION
SELECT 'Employee',		COUNT(*)		FROM Employee		UNION
SELECT 'Inventory',         COUNT(*)		FROM Inventory	UNION
SELECT 'OrderLine',		COUNT(*)		FROM Orderline	UNION
SELECT 'Order',		COUNT(*)		FROM [Order]		UNION
SELECT 'State',		COUNT(*)		FROM State             
ORDER BY 1;
SET NOCOUNT OFF
GO
